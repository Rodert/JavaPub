# examination_system-
这是个基于SSM+Bootstrap的教务查询系统，是一个简单的教务查询系统.

做了关于数据库的增删改查练习。
用来熟悉SSM的整合开发。
使用技术 
IOC容器：Spring Web框架：SpringMVC 
ORM框架：Mybatis 
数据源：C3P0 
日志：log4j 
前端框架：Bootstrap 
运行环境 jdk8+tomcat8+mysql+Eclipse+maven
项目技术： spring+spring mvc+mybatis+bootstrap+jquery

具体页面：
登录页：
![Alt text]

管理员页：管理员账户：admin+123
![Alt text]

学生页：学生登录: 10001+123
![Alt text]

老师页：教师登录：1001+123
![Alt text]

一些功能：
![Alt text]



