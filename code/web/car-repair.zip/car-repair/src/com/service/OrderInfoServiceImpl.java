package com.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dao.OrderInfoDao;
import com.entity.OrderInfo;
import com.entity.TroubleInfo;
import com.util.IDUtil;
import com.util.Result;
@Service
public class OrderInfoServiceImpl implements OrderInfoService{

	@Resource
	OrderInfoDao dao;
	
	@Override
	public Result addOrderInfo(String user_id, String user_name, String plate, String trouble_code,String trouble_name, String contact,
			String contact_way, String remark) {
		// TODO Auto-generated method stub
		OrderInfo oi=new OrderInfo();
		String id=IDUtil.createId();
		oi.setId(id);
		oi.setUser_id(user_id);
		oi.setUser_name(user_name);
		oi.setPlate(plate);
		oi.setTrouble_code(trouble_code);
		oi.setTrouble_name(trouble_name);
		oi.setContact(contact);
		oi.setContact_way(contact_way);
		oi.setRemark(remark);
		oi.setCreart_time(getTime());
		oi.setLong_time(System.currentTimeMillis());
		oi.setStatus(0);
		dao.addOrderInfo(oi);
		return new Result("0", "������Ϣ���ӳɹ�", null);
	}

	private static String getTime(){
		SimpleDateFormat formatter=new SimpleDateFormat("yyyy��MM��dd��   HH:mm:ss");       
		Date curDate=new Date(System.currentTimeMillis());//��ȡ��ǰʱ��       
		String str=formatter.format(curDate); 
		return str;
	}


	@Override
	public Result findAllOrder() {
		// TODO Auto-generated method stub
		List<OrderInfo> list=dao.findAllOrder();
		return new Result("0", "������Ϣ���سɹ�", list);
	}

	@Override
	public Result delOrderInfo(String id) {
		// TODO Auto-generated method stub
		dao.delOrderInfo(id);
		return new Result("0", "������Ϣɾ���ɹ�", null);
	}

	@Override
	public Result changStatus(String id) {
		// TODO Auto-generated method stub
		dao.changStatus(id, 1);
		return new Result("0", "����״̬���ĳɹ�", null);
	}

	@Override
	public Result findOrder(String user_id) {
		// TODO Auto-generated method stub
		List<OrderInfo> list=dao.findOrder(user_id);
		return new Result("0", "������Ϣ���سɹ�", list);
	}

	@Override
	public Result searchOrderInfo(String type, String keywords) {
		// TODO Auto-generated method stub
		Map<String,Object> params=new HashMap<String,Object>();
		if(!type.equals("") && keywords.equals("")){
			return new Result("1", "������ؼ���", null);
		}else if(type.equals("") && !keywords.equals("")){
			return new Result("1", "��ѡ�����", null);
		}else if(type.equals("1")){
			params.put("plate", "%"+keywords+"%");
		}else if(type.equals("2")){
			params.put("trouble_name", "%"+keywords+"%");
		}else if(type.equals("3")){
			params.put("user_name", "%"+keywords+"%");
		}else if(type.equals("4")){
			params.put("contact", "%"+keywords+"%");
		}
		List<OrderInfo> list=dao.searchOrderInfo(params);
		return new Result("0", "������Ϣ���سɹ�", list);
	}

	@Override
	public Result findDealOrder() {
		// TODO Auto-generated method stub
		List<OrderInfo> list=dao.findByStatus(1);
		return new Result("0", "������Ϣ���سɹ�", list);
	}

	@Override
	public Result  findUndealOrder() {
		// TODO Auto-generated method stub
		List<OrderInfo> list=dao.findByStatus(0);
		return new Result("0", "������Ϣ���سɹ�", list);
	}

	@Override
	public Result findBySort() {
		// TODO Auto-generated method stub
		List<OrderInfo> list=dao.findBySort();
		return new Result("0", "������Ϣ���سɹ�", list);
	}
	
}
