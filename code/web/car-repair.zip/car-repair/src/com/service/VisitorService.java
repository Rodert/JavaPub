package com.service;

import java.util.List;

import com.entity.Visitor;
import com.util.Result;

public interface VisitorService {
	public Result visitorList();
}
