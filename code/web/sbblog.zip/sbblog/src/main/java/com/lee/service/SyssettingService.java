package com.lee.service;

import com.lee.entity.Syssetting;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author lee
 * @since 2020-02-24
 */
public interface SyssettingService extends IService<Syssetting> {

}
