package com.lee.mapper;

import com.lee.entity.Syssetting;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author lee
 * @since 2020-02-24
 */
public interface SyssettingMapper extends BaseMapper<Syssetting> {

}
